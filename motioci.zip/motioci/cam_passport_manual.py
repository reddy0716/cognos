#!/usr/bin/env python3
"""
Simple CAM Passport manual extraction helper
This approach acknowledges that automated extraction might be complex
and provides a simple way to get a fresh CAM Passport
"""

import requests
import sys
import os

def test_cam_passport(cognos_url, username, password, namespace="AzureAD"):
    """
    Test if we can get a fresh CAM Passport manually
    """
    print("=" * 60)
    print("CAM Passport Manual Extraction Helper")
    print("=" * 60)
    print(f"Server: {cognos_url}")
    print(f"Username: {username}")
    print(f"Namespace: {namespace}")
    print()
    
    print("MANUAL STEPS:")
    print("1. Open browser and go to:", f"{cognos_url}/bi/")
    print("2. Login with:")
    print(f"   - Username: {username}")
    print(f"   - Password: [hidden]")
    print(f"   - Namespace: {namespace}")
    print("3. After login, open browser Developer Tools (F12)")
    print("4. Go to Application > Cookies")
    print("5. Look for cookies containing 'CAMPassport' or 'passport'")
    print("6. Copy the value and update the Jenkins credential")
    print()
    
    # Try a simple automated check
    session = requests.Session()
    session.verify = False
    
    print("Attempting automated extraction...")
    
    # Try the standard Cognos dispatch servlet
    auth_url = f"{cognos_url}/p2pd/servlet/dispatch"
    auth_data = {
        'CAMUsername': username,
        'CAMPassword': password,
        'CAMNamespace': namespace,
        'h_CAM_action': 'logonAs'
    }
    
    try:
        response = session.post(auth_url, data=auth_data, timeout=10)
        print(f"Auth response status: {response.status_code}")
        
        # Check cookies
        passport_cookies = []
        for cookie in session.cookies:
            if 'passport' in cookie.name.lower() or 'cam' in cookie.name.lower():
                passport_cookies.append(f"{cookie.name}: {cookie.value[:50]}...")
        
        if passport_cookies:
            print("Found potential CAM Passport cookies:")
            for cookie_info in passport_cookies:
                print(f"  {cookie_info}")
            
            # Return the first one that looks substantial
            for cookie in session.cookies:
                if ('passport' in cookie.name.lower() or 'cam' in cookie.name.lower()) and len(cookie.value) > 30:
                    return cookie.value
        else:
            print("No CAM Passport cookies found automatically")
            
    except Exception as e:
        print(f"Automated extraction failed: {e}")
    
    print("\nIf automated extraction failed, please follow manual steps above.")
    return None

if __name__ == "__main__":
    # Command line arguments take priority over environment variables
    if len(sys.argv) >= 4:
        cognos_url = sys.argv[1]
        username = sys.argv[2]
        password = sys.argv[3]
        namespace = sys.argv[4] if len(sys.argv) > 4 else 'AzureAD'
    else:
        # Fall back to environment variables
        cognos_url = os.getenv('COGNOS_SERVER_URL', 'https://cgrptmcip01.cloud.cammis.ca.gov')
        username = os.getenv('COGNOS_USERNAME')
        password = os.getenv('COGNOS_PASSWORD')
        namespace = os.getenv('COGNOS_NAMESPACE', 'AzureAD')
    
    if not username or not password:
        print("Usage: python cam_passport_manual.py <url> <username> <password> [namespace]")
        print("Or set environment variables: COGNOS_USERNAME, COGNOS_PASSWORD")
        sys.exit(1)
    
    passport = test_cam_passport(cognos_url, username, password, namespace)
    if passport:
        print(f"\nSUCCESS! CAM_PASSPORT={passport}")
    else:
        print("\nPlease follow manual extraction steps.")
        sys.exit(1)
