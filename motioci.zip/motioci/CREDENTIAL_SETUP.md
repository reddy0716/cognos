# Jenkins Credential Setup Guide

## Required Jenkins Credentials:

### 1. Cognos Production Credentials
- **Credential Type**: Username with password
- **ID**: `cognos-prod-credentials`
- **Username**: Your production Cognos username
- **Password**: Your production Cognos password

### 2. Cognos Namespace
- **Credential Type**: Secret text
- **ID**: `cognos-namespace`
- **Secret**: `AzureAD` (or your specific namespace)

### 3. CAM Passport (Manual Fallback)
- **Credential Type**: Secret text
- **ID**: `cognos-cam-passport`
- **Secret**: Current CAM Passport ID (manually extracted)

### 4. MotioCI Credentials (existing)
- **Credential Type**: Secret file
- **ID**: `prod-credentials-json`
- **File**: Your MotioCI credentials JSON

## Simplified Pipeline Approach:

Instead of trying to automate CAM Passport extraction (which is complex),
consider this simpler approach:

1. **Manual CAM Passport Refresh**: 
   - Use `cam_passport_manual.py` to help extract current passport
   - Update Jenkins credential `cognos-cam-passport` when needed

2. **Automated Validation**: 
   - Pipeline can test if current CAM Passport is still valid
   - If invalid, fail with clear instructions to refresh it

3. **Hybrid Approach**:
   - Try automated extraction first
   - Fall back to manual credential if automation fails
   - Log clear instructions for updating the credential

This is more reliable than complex automation that might break with Cognos updates.
