# Credential Verification Checklist

## Required Jenkins Credentials (Check if these exist):

1. **prod-credentials-json** (Secret File)
   - Should contain MotioCI login credentials in JSON format
   - Check: Jenkins > Manage Jenkins > Credentials

2. **cognos-prod-credentials** (Username with Password)
   - Username: Your Cognos production username
   - Password: Your Cognos production password
   - Check: This credential must be created

3. **cognos-cam-passport** (Secret Text)
   - Current CAM Passport ID (manually extracted)
   - Check: This credential must be created

## If Credentials Don't Exist:
The pipeline will fail with "Credentials not found" errors.

## Solution:
Create missing credentials in Jenkins or update credential IDs in the pipeline.
