# Jenkins Pipeline Configuration Summary

## Environment Variables Defined in Pipeline

All configuration is now centralized in the pipeline's `environment` block:

### Server Configuration
- `COGNOS_SERVER_URL`: "https://cgrptmcip01.cloud.cammis.ca.gov"
- `COGNOS_NAMESPACE`: "AzureAD"

### Deployment Configuration  
- `SOURCE_INSTANCE_ID`: "3"
- `TARGET_INSTANCE_ID`: "1"
- `LABEL_ID`: "57"
- `PROJECT_NAME`: "Demo"

## Required Jenkins Credentials

### 1. MotioCI Credentials
- **ID**: `prod-credentials-json`
- **Type**: Secret file
- **Content**: MotioCI login credentials JSON

### 2. Cognos Production Login
- **ID**: `cognos-prod-credentials`
- **Type**: Username with password
- **Username**: Your Cognos production username
- **Password**: Your Cognos production password

### 3. Manual CAM Passport (Fallback)
- **ID**: `cognos-cam-passport`
- **Type**: Secret text
- **Content**: Current CAM Passport ID (manually extracted when needed)

## Script Usage

### CAM Passport Extraction
```bash
# Command line arguments (preferred in pipeline)
python3 cam_passport_extractor.py <url> <username> <password> [namespace]

# Environment variables (fallback)
export COGNOS_SERVER_URL="https://cgrptmcip01.cloud.cammis.ca.gov"
export COGNOS_USERNAME="your_username"
export COGNOS_PASSWORD="your_password"
export COGNOS_NAMESPACE="AzureAD"
python3 cam_passport_extractor.py
```

### Manual CAM Passport Helper
```bash
# For troubleshooting and manual extraction
python3 cam_passport_manual.py <url> <username> <password> [namespace]
```

## Pipeline Flow

1. **Environment Setup**: All config variables defined in pipeline environment
2. **MotioCI Login**: Load credentials and get auth token
3. **CAM Passport Extraction**: 
   - Try automated extraction with command line args
   - Fall back to manual credential if automated fails
   - Fail pipeline if no valid CAM Passport available
4. **Deployment**: Use all environment variables for configurable deployment
5. **Verification**: Check deployment success

## Benefits of This Approach

- ✅ **Centralized Configuration**: All settings in one place
- ✅ **Secure Credential Management**: Uses Jenkins credentials properly  
- ✅ **Command Line Arguments**: Clean parameter passing to scripts
- ✅ **Configurable**: Easy to change deployment parameters
- ✅ **Maintainable**: Clear separation of config vs secrets
- ✅ **Debuggable**: Clear logging and error handling
