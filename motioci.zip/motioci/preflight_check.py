#!/usr/bin/env python3
"""
Pre-flight check script to validate pipeline configuration
Run this before executing the Jenkins pipeline
"""

import requests
import sys
import os

def check_cognos_server(server_url):
    """Check if Cognos server is accessible"""
    try:
        print(f"Checking Cognos server accessibility: {server_url}")
        response = requests.get(f"{server_url}/bi/", timeout=10, verify=False)
        if response.status_code == 200:
            print("✅ Cognos server is accessible")
            return True
        else:
            print(f"⚠️  Cognos server returned status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Cognos server check failed: {e}")
        return False

def check_motio_server(server_url):
    """Check if MotioCI server is accessible"""
    try:
        print(f"Checking MotioCI server accessibility: {server_url}")
        response = requests.get(f"{server_url}/api/", timeout=10, verify=False)
        print(f"✅ MotioCI server is accessible (status: {response.status_code})")
        return True
    except Exception as e:
        print(f"❌ MotioCI server check failed: {e}")
        return False

def validate_credentials(username, password):
    """Basic credential validation"""
    if not username or not password:
        print("❌ Username or password is missing")
        return False
    
    if len(username) < 3:
        print("❌ Username seems too short")
        return False
        
    if len(password) < 8:
        print("❌ Password seems too short")
        return False
        
    print("✅ Credentials format looks valid")
    return True

def main():
    print("=" * 60)
    print("MotioCI Pipeline Pre-flight Check")
    print("=" * 60)
    
    # Configuration from environment or defaults
    cognos_server = os.getenv('COGNOS_SERVER_URL', 'https://cgrptmcip01.cloud.cammis.ca.gov')
    username = os.getenv('COGNOS_USERNAME', '')
    password = os.getenv('COGNOS_PASSWORD', '')
    
    # Allow command line override
    if len(sys.argv) >= 4:
        cognos_server = sys.argv[1]
        username = sys.argv[2]
        password = sys.argv[3]
    
    all_checks_passed = True
    
    print("\n1. Server Accessibility Checks:")
    if not check_cognos_server(cognos_server):
        all_checks_passed = False
    
    if not check_motio_server(cognos_server):
        all_checks_passed = False
    
    print("\n2. Credential Validation:")
    if not validate_credentials(username, password):
        all_checks_passed = False
    
    print("\n3. Configuration Summary:")
    print(f"   Cognos Server: {cognos_server}")
    print(f"   Username: {username if username else 'NOT SET'}")
    print(f"   Password: {'SET' if password else 'NOT SET'}")
    
    print("\n" + "=" * 60)
    if all_checks_passed:
        print("✅ All pre-flight checks PASSED")
        print("Pipeline should run successfully")
        sys.exit(0)
    else:
        print("❌ Some pre-flight checks FAILED")
        print("Fix the issues before running the pipeline")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "--help":
        print("Usage: python preflight_check.py [cognos_url] [username] [password]")
        print("Or set environment variables: COGNOS_SERVER_URL, COGNOS_USERNAME, COGNOS_PASSWORD")
        sys.exit(0)
    
    main()
