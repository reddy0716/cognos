#!/usr/bin/env python3
import requests
import json
import re
import sys
import os

# Disable SSL warnings
requests.packages.urllib3.disable_warnings()

def extract_cam_passport_simple(cognos_server_url, username, password, namespace="AzureAD"):
    """
    Simple CAM Passport extraction from Cognos using direct authentication
    """
    session = requests.Session()
    session.verify = False
    
    try:
        print(f"Extracting CAM Passport from: {cognos_server_url}")
        print(f"Username: {username}")
        print(f"Namespace: {namespace}")
        
        # Common Cognos authentication endpoints
        auth_endpoints = [
            f"{cognos_server_url}/p2pd/servlet/dispatch",
            f"{cognos_server_url}/bi/v1/disp/rds/auth/logon", 
            f"{cognos_server_url}/bi/v1/auth/login"
        ]
        
        for auth_url in auth_endpoints:
            print(f"Trying endpoint: {auth_url}")
            
            # Standard Cognos authentication payload
            auth_data = {
                'CAMUsername': username,
                'CAMPassword': password,
                'CAMNamespace': namespace,
                'h_CAM_action': 'logonAs',
                'ui.action': 'logon',
                'ui.object': 'logon'
            }
            
            try:
                response = session.post(auth_url, data=auth_data, timeout=30, allow_redirects=True)
                print(f"Response status: {response.status_code}")
                
                # Look for CAM Passport in cookies
                for cookie in session.cookies:
                    if 'passport' in cookie.name.lower() or 'cam' in cookie.name.lower():
                        if len(cookie.value) > 30:  # Valid passport length
                            print(f"Found CAM Passport in cookie: {cookie.name}")
                            return cookie.value
                
                # Look for CAM Passport in response headers
                for header, value in response.headers.items():
                    if 'passport' in header.lower() and len(value) > 30:
                        print(f"Found CAM Passport in header: {header}")
                        return value
                
                # Look for CAM Passport in response body
                if response.text:
                    # Simple regex patterns for CAM Passport
                    patterns = [
                        r'CAMPassport["\']?\s*[:=]\s*["\']?([A-Za-z0-9+/=]{40,})',
                        r'passport["\']?\s*[:=]\s*["\']?([A-Za-z0-9+/=]{40,})'
                    ]
                    
                    for pattern in patterns:
                        match = re.search(pattern, response.text, re.IGNORECASE)
                        if match:
                            passport = match.group(1)
                            if len(passport) > 30:
                                print(f"Found CAM Passport in response body")
                                return passport
                            
            except Exception as e:
                print(f"Endpoint {auth_url} failed: {str(e)}")
                continue
        
        print("No CAM Passport found in any endpoint")
        return None
        
    except Exception as e:
        print(f"Error extracting CAM Passport: {str(e)}")
        return None

if __name__ == "__main__":
    # Command line arguments take priority over environment variables
    if len(sys.argv) >= 4:
        cognos_url = sys.argv[1]
        username = sys.argv[2]
        password = sys.argv[3]
        namespace = sys.argv[4] if len(sys.argv) > 4 else 'AzureAD'
    else:
        # Fall back to environment variables
        cognos_url = os.getenv('COGNOS_SERVER_URL', 'https://cgrptmcip01.cloud.cammis.ca.gov')
        username = os.getenv('COGNOS_USERNAME')
        password = os.getenv('COGNOS_PASSWORD')
        namespace = os.getenv('COGNOS_NAMESPACE', 'AzureAD')
    
    if not username or not password:
        print("ERROR: Username and password required")
        print("Usage: python cam_passport_extractor.py <url> <username> <password> [namespace]")
        print("Or set environment variables: COGNOS_USERNAME, COGNOS_PASSWORD")
        sys.exit(1)
    
    passport = extract_cam_passport_simple(cognos_url, username, password, namespace)
    if passport:
        print(f"CAM_PASSPORT={passport}")
        sys.exit(0)
    else:
        print("Failed to extract CAM Passport")
        sys.exit(1)
